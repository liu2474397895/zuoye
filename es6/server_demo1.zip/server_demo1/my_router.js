// fs: fiel system 文件系统模块
// 是 node 环境自带的
// 所以 不用 安装
const fs = require("fs")
const router = require('koa-router')();

let User_img = ""

router
    .get("/" ,  ctx => {
        // ctx.response.body = "主界面"
        ctx.body = "主界面1122211"
    })
    .get("/xiaomi" ,  ctx => {
        ctx.body = "小米界面222"
    })
    .get("/jingdong" , ctx => {
        ctx.body = "京东界面222"
    })
    .get("/userInfo" , ctx => {
        ctx.body = '{"name": "zhangsan","head_img": "' + User_img + '"}'
    })
    .get("/aaa" , ctx => {
        console.log("aaaaaa---get")
        console.log(ctx.request.query)
        ctx.body = "aaaaaa--get"
    })

    .post("/logn_api" , ctx => {
        console.log("aaaaaa---post")
        let post_data = ctx.request.body
        console.log(post_data)

        if (post_data.username =="zhangsan" && post_data.pwd == "123456") {
            let suc_obj = {
                code: 0,
                msg: "登录成功"
            }
            ctx.body = JSON.stringify(suc_obj)
        } else {
            let err_obj = {
                code: 1,
                msg: "登录失败"
            }
            ctx.body = JSON.stringify(err_obj)
        }
        
    })
    .post("/upload" , ctx => {
        let file = ctx.request.files.head_img
        let f_name = new Date().getTime() + "." + file.name.split(".")[1]
        let f_stream = file.path

        let du = fs.createReadStream(f_stream)
        let xie = fs.createWriteStream("./static/head_img/" + f_name)
        du.pipe(xie)

        User_img = "head_img/" + f_name;

        let suc_obj = {
            code: 0,
            msg: "上传成功" , 
            data: "head_img/" + f_name
        }
        ctx.body = JSON.stringify(suc_obj)
    })


module.exports = router